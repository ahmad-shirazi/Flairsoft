MIME_TYPES = {
    "pdf": 'application/pdf',
    "image": 'image/tiff'
}

# sample gs://ocr_input/00000231.PDF
GOOGLE_CLOUD_URL = "gs://{}/{}"
